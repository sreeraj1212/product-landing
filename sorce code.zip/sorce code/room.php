<?php
// Database connection
$conn = new mysqli("localhost", "username", "password", "database_name");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get room details based on ID
$room_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$sql = "SELECT name, description, ip_address FROM rooms WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $room_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $room = $result->fetch_assoc();
    ?>
    
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <title><?php echo htmlspecialchars($room['name']); ?></title>
    </head>
    <body>
        <h1><?php echo htmlspecialchars($room['name']); ?></h1>
        <p><?php echo htmlspecialchars($room['description']); ?></p>
        <p>IP Address: <?php echo htmlspecialchars($room['ip_address']); ?></p>
    </body>
    </html>
    
    <?php
} else {
    echo "<p>Room not found.</p>";
}

$stmt->close();
$conn->close();
?>
